# Viva Questions and Answers

**1. What is a multi-agent system?**  
A system where multiple software agents have different responsibilities and cooperate to solve a task.

**2. Why did you create separate agents?**  
Separation of responsibilities makes the workflow easier to understand, test, and maintain.

**3. What does the Manager Agent do?**  
It breaks the user's request into smaller steps.

**4. What does the Research Agent do in this version?**  
It organizes user-provided information and points out missing context. It does not browse the internet.

**5. Does the Execution Agent modify real systems?**  
No. It only recommends an action plan. Real actions would need integrations and approval.

**6. What is the Quality Agent checking?**  
It checks that context is present, the plan has multiple steps, and a human-approval reminder exists.

**7. What is Streamlit?**  
A Python framework for building interactive web applications quickly.

**8. Why is there no API key?**  
The current prototype uses rule-based logic rather than a hosted AI model.

**9. What is orchestration?**  
Coordinating the order in which agents perform their tasks and pass outputs to later steps.

**10. What is the main limitation?**  
The agents do not use an LLM or live operational data, and task history is temporary.

**11. How can you improve it?**  
Add an LLM, persistent database, login, audit logs, and approved integrations.

**12. What is human-in-the-loop?**  
A design in which a person reviews or approves important decisions before they are carried out.

**13. What is the role of Pandas?**  
It formats task history as a table for the dashboard.

**14. How do you run the project?**  
Install the packages and run `python -m streamlit run app.py`.

**15. Is the current system fully autonomous?**  
No. It is a controlled workflow demonstration that generates recommendations, not a system that independently changes infrastructure.
